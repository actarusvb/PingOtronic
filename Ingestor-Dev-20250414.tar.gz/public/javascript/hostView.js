

$( document ).ready(function() {
	let host = new DataTable('#hostsTable',{
		lengthMenu: [
			[20, 60, 90, -1],
			[20, 60, 90, 'All']
		]
	});
	let badhost = new DataTable('#badHostsTable',{
		lengthMenu: [
			[20, 60, 90, -1],
			[20, 60, 90, 'All']
		]
	});
});